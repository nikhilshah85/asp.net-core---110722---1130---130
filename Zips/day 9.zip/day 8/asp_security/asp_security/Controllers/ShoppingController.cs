﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace asp_security.Controllers
{

    [Authorize]
    public class ShoppingController : Controller
    {
        [AllowAnonymous]
        public IActionResult ProductList()
        {
            return View();
        }

        public IActionResult PlaceOrder()
        {
            return View();
        }

        public IActionResult ViewTransactions()
        {
            return View();
        }
    }
}
